# =============================================================================
# run.py  —  Entry point. Run a single simulation or full Monte Carlo.
# =============================================================================
#
# Usage:
#   python run.py              →  single base-case run + charts
#   python run.py --mc         →  full Monte Carlo (500 runs, slow)
#   python run.py --mc --n 50  →  quick MC with 50 runs
#
# =============================================================================

import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from pathlib import Path

import config
from simulation import Simulation, SimParams
from monte_carlo import run_monte_carlo, percentile_summary, binding_tier


# =============================================================================
# Single run
# =============================================================================
def run_single():
    print("Running base-case simulation...")
    sim   = Simulation(SimParams(seed=config.MC_SEED))
    snaps = sim.run()
    df    = Simulation.to_dataframe(snaps)

    print(f"\n{'Year':>6}  {'Total Workers':>14}  {'System Vacuum':>14}  "
          f"{'Binding Tier':>13}  {'Pool':>6}")
    print("-" * 62)

    for year in sorted(df["year"].unique()):
        ydf  = df[df["year"] == year]
        total_workers = ydf.groupby("year")["headcount"].sum().values[0]
        total_vacuum  = ydf["vacuum"].sum()
        binding       = ydf.loc[ydf["vacuum"].idxmax(), "tier"]
        pool          = ydf["pool_size"].values[0]
        print(f"{year:>6.2f}  {total_workers:>14,}  {total_vacuum:>14.1f}  "
              f"{binding:>13.1f}  {pool:>6}")

    _plot_single(df)
    return df


# =============================================================================
# Monte Carlo run
# =============================================================================
def run_mc(n_runs: int = config.MC_RUNS):
    print(f"\nRunning Monte Carlo ({n_runs} simulations)...")
    df      = run_monte_carlo(n_runs=n_runs)
    summary = percentile_summary(df, metric="vacuum")
    btier   = binding_tier(df)

    print(f"\n── System-level vacuum P5/P50/P95 at 2033 ──")
    final_year = df["year"].max()
    final = summary[summary["year"] == final_year]
    total = final.groupby("year")[["P5","P50","P95"]].sum()
    print(total.to_string())

    print(f"\n── Most common binding tier (2033) ──")
    last_btier = btier[btier["year"] == final_year]
    print(last_btier["binding_tier"].value_counts().head(5).to_string())

    _plot_mc(summary)
    return df, summary


# =============================================================================
# Plots
# =============================================================================
def _plot_single(df: pd.DataFrame):
    fig, axes = plt.subplots(2, 2, figsize=(14, 9))
    fig.suptitle("Labour Vacuum Simulation — Base Case", fontsize=14)

    years  = sorted(df["year"].unique())
    tiers  = sorted(df["tier"].unique())
    colors = cm.RdYlGn_r(np.linspace(0.1, 0.9, len(tiers)))

    # Chart 1: Vacuum per tier over time
    ax = axes[0, 0]
    for tier, col in zip(tiers, colors):
        tdf = df[df["tier"] == tier]
        ax.plot(tdf["year"], tdf["vacuum"], label=f"Tier {tier:.1f}", color=col)
    ax.set_title("Vacuum by tier (000 effective workers)"); ax.set_xlabel("Year")
    ax.legend(fontsize=7, ncol=2)

    # Chart 2: Fill % per tier over time
    ax = axes[0, 1]
    for tier, col in zip(tiers, colors):
        tdf = df[df["tier"] == tier]
        ax.plot(tdf["year"], tdf["fill_pct"] * 100, color=col, label=f"{tier:.1f}")
    ax.axhline(100, color="grey", linestyle="--", linewidth=0.8)
    ax.set_title("Fill % by tier"); ax.set_xlabel("Year"); ax.set_ylabel("%")

    # Chart 3: Total headcount over time
    ax = axes[1, 0]
    total_hc = df.groupby("year")["headcount"].sum()
    ax.plot(total_hc.index, total_hc.values, color="#2563eb", linewidth=2)
    ax.set_title("Total workforce headcount"); ax.set_xlabel("Year")

    # Chart 4: Exit breakdown over time
    ax = axes[1, 1]
    for col, label, colour in [
        ("exits_quit",  "Voluntary quit", "#f97316"),
        ("exits_ret",   "Retirement",     "#ef4444"),
        ("exits_shock", "Shock",          "#7c3aed"),
    ]:
        series = df.groupby("year")[col].sum() / len(tiers)
        ax.plot(series.index, series.values, label=label, color=colour)
    ax.set_title("Exits per quarter"); ax.set_xlabel("Year")
    ax.legend(fontsize=8)

    plt.tight_layout()
    out = Path("output_single.png")
    plt.savefig(out, dpi=150)
    print(f"\nChart saved → {out.resolve()}")
    plt.show()


def _plot_mc(summary: pd.DataFrame):
    fig, axes = plt.subplots(2, 2, figsize=(14, 9))
    fig.suptitle("Labour Vacuum — Monte Carlo P5/P50/P95", fontsize=14)
    tiers  = sorted(summary["tier"].unique())
    colors = cm.RdYlGn_r(np.linspace(0.1, 0.9, len(tiers)))

    # Chart 1: P50 vacuum per tier
    ax = axes[0, 0]
    for tier, col in zip(tiers, colors):
        tdf = summary[summary["tier"] == tier]
        ax.plot(tdf["year"], tdf["P50"], color=col, label=f"{tier:.1f}")
        ax.fill_between(tdf["year"], tdf["P5"], tdf["P95"],
                        color=col, alpha=0.08)
    ax.set_title("Vacuum P50 by tier (shaded P5–P95)")
    ax.legend(fontsize=7, ncol=2)

    # Chart 2: Total system vacuum P5/P50/P95
    ax = axes[0, 1]
    sys = summary.groupby("year")[["P5","P50","P95"]].sum().reset_index()
    ax.plot(sys["year"], sys["P50"], color="#ef4444", linewidth=2, label="P50")
    ax.fill_between(sys["year"], sys["P5"], sys["P95"],
                    color="#ef4444", alpha=0.15, label="P5–P95")
    ax.set_title("System-level vacuum P5/P50/P95")
    ax.legend()

    # Chart 3: Fill % P50 per tier
    ax = axes[1, 0]
    fp_summary = percentile_summary.__module__  # placeholder label
    for tier, col in zip(tiers, colors):
        tdf = summary[summary["tier"] == tier]
        ax.plot(tdf["year"], tdf["P50"] * 0 + 80,  # PLACEHOLDER line
                color=col, alpha=0.2)
    ax.set_title("Fill % P50 (placeholder — wire to fill_pct in next iteration)")

    # Chart 4: Heatmap of vacuum by tier × year (P50)
    ax = axes[1, 1]
    pivot = summary.pivot(index="tier", columns="year", values="P50")
    im = ax.imshow(pivot.values, aspect="auto", cmap="RdYlGn_r",
                   origin="lower")
    ax.set_yticks(range(len(tiers)))
    ax.set_yticklabels([f"{t:.1f}" for t in tiers], fontsize=8)
    ax.set_title("Vacuum heatmap: tier × year (P50)")
    plt.colorbar(im, ax=ax, label="vacuum (000s)")

    plt.tight_layout()
    out = Path("output_mc.png")
    plt.savefig(out, dpi=150)
    print(f"\nMC chart saved → {out.resolve()}")
    plt.show()


# =============================================================================
# CLI
# =============================================================================
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mc",  action="store_true", help="Run Monte Carlo")
    parser.add_argument("--n",   type=int, default=config.MC_RUNS,
                        help="Number of MC runs (default: config.MC_RUNS)")
    args = parser.parse_args()

    if args.mc:
        run_mc(n_runs=args.n)
    else:
        run_single()
