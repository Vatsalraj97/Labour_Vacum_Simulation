# =============================================================================
# simulation.py  —  Main orchestrator: initialise + run one full simulation
# =============================================================================

from __future__ import annotations
import random
import numpy as np
import pandas as pd
from typing import Dict, List, Optional
from dataclasses import dataclass, field

import config
from entities import Ball, Tube, MarketPool
from growth_engine     import grow_all
from exit_engine       import process_exits, exit_summary
from inflow_engine     import add_quarterly_entrants
from graduation_engine import process_graduations


# =============================================================================
# Parameter bundle (one instance per MC run)
# =============================================================================
@dataclass
class SimParams:
    """
    All tuneable parameters for one simulation run.
    Defaults come from config.py — Monte Carlo overrides them per run.
    """
    alpha             : float = config.ALPHA
    beta              : float = config.BETA
    base_growth_rate  : float = config.BASE_GROWTH_RATE
    mfg_entry_pct     : float = config.MFG_ENTRY_PCT
    shock_probability : float = config.SHOCK_PROBABILITY
    shock_removal_rate: float = config.SHOCK_REMOVAL_RATE
    industry_growth   : float = config.INDUSTRY_GROWTH_RATE
    reshoring_total_m : float = config.RESHORING_TOTAL_M
    placement_prob    : float = config.PLACEMENT_PROBABILITY
    seed              : int   = 42


# =============================================================================
# Snapshot — state of system at one timestep
# =============================================================================
@dataclass
class Snapshot:
    step        : int
    year        : float
    total_balls : int
    pool_size   : int
    per_tube    : List[dict]   # one dict per tube
    exits       : dict


# =============================================================================
# Simulation
# =============================================================================
class Simulation:
    """
    Runs a complete 2025–2033 labour market simulation (32 quarters).

    Usage:
        sim = Simulation(SimParams(seed=42))
        snapshots = sim.run()
        df = sim.to_dataframe(snapshots)
    """

    def __init__(self, params: SimParams = None):
        self.params = params or SimParams()
        self.rng    = random.Random(self.params.seed)
        np.random.seed(self.params.seed)

        self.tubes_by_tier: Dict[float, Tube] = {}
        self.pool = MarketPool()
        self._initialise_tubes()
        self._populate_initial_workforce()

    # ── Setup ─────────────────────────────────────────────────────────────────

    def _initialise_tubes(self):
        """Create one Tube per tier. Set initial demand height."""
        for tier in config.TUBE_TIERS:
            diameter = tier * config.TUBE_DIAMETER_SCALE

            # Initial demand = share of initial workforce for this tier
            share    = config.INITIAL_TIER_DISTRIBUTION.get(tier, 0.0)
            # demand_height in thousands of effective worker-units
            demand   = (config.INITIAL_WORKFORCE * share) / 1000.0

            self.tubes_by_tier[tier] = Tube(
                tier          = tier,
                diameter      = diameter,
                demand_height = demand,
            )

    def _populate_initial_workforce(self):
        """
        Distribute INITIAL_WORKFORCE balls across tubes according to
        INITIAL_TIER_DISTRIBUTION. Each ball gets a randomised skill
        value within its tube's range [tier-0.1, tier].
        """
        for tier, tube in self.tubes_by_tier.items():
            share = config.INITIAL_TIER_DISTRIBUTION.get(tier, 0.0)
            n_workers = int(config.INITIAL_WORKFORCE * share)

            for _ in range(n_workers):
                # Skill uniformly distributed within [tier-0.09, tier]
                low   = max(tier - 0.09, 0.01)
                skill = self.rng.uniform(low, tier)

                # PLACEHOLDER: initial tenure distribution
                # Currently random 0–40 quarters
                # Real: fit against BLS tenure supplement data
                tenure = self.rng.randint(0, 40)
                age_q  = min(tenure // 10 + 1, 4)

                ball = Ball(
                    skill        = skill,
                    tube_tier    = tier,
                    tenure       = tenure,
                    tube_tenure  = self.rng.randint(0, tenure),
                    age_quartile = age_q,
                    immigrant    = self.rng.random() < 0.102,
                )
                tube.balls.append(ball)

    # ── Demand update ─────────────────────────────────────────────────────────

    def _update_demand(self, step: int):
        """
        Raise tube demand heights each quarter based on:
        1. Industry output growth (raises all tiers proportionally)
        2. Reshoring demand (weighted towards mid tiers)

        PLACEHOLDER: reshoring is spread evenly over 36 quarters.
        Real implementation: use Reshoring Initiative project pipeline
        data to schedule demand spikes in specific quarters.
        """
        quarterly_growth = self.params.industry_growth / config.QUARTERS_PER_YEAR
        quarterly_reshoring_m = (
            self.params.reshoring_total_m / config.TOTAL_STEPS
        )  # M workers per quarter

        for tier, tube in self.tubes_by_tier.items():
            # Growth raises all tiers
            tube.demand_height *= (1 + quarterly_growth)

            # Reshoring adds to mid-tier tubes only
            weight = config.RESHORING_TIER_WEIGHTS.get(tier, 0.0)
            tube.demand_height += (
                quarterly_reshoring_m * weight * 1000   # convert M → thousands
            )

    # ── Main loop ─────────────────────────────────────────────────────────────

    def run(self) -> List[Snapshot]:
        """
        Execute all 32 quarters. Returns a list of Snapshot objects.
        Order of operations each quarter:
          1. Update demand (raise tube heights)
          2. Add new entrants (inflow)
          3. Grow existing workers (growth engine)
          4. Graduate skilled workers (graduation engine)
          5. Remove exiting workers (exit engine)
          6. Record snapshot
        """
        snapshots = []

        for step in range(config.TOTAL_STEPS):
            year = config.START_YEAR + step / config.QUARTERS_PER_YEAR

            # 1. Demand
            self._update_demand(step)

            # 2. Inflow
            add_quarterly_entrants(
                self.tubes_by_tier,
                mfg_entry_pct = self.params.mfg_entry_pct,
                rng           = self.rng,
            )

            # 3. Growth
            grow_all(
                list(self.tubes_by_tier.values()),
                alpha = self.params.alpha,
                beta  = self.params.beta,
            )

            # 4. Graduation
            process_graduations(
                self.tubes_by_tier,
                self.pool,
                placement_prob = self.params.placement_prob,
                rng            = self.rng,
            )

            # 5. Exits
            exit_log = process_exits(
                list(self.tubes_by_tier.values()),
                shock_probability  = self.params.shock_probability,
                shock_removal_rate = self.params.shock_removal_rate,
                rng                = self.rng,
            )

            # 6. Snapshot
            snap = self._snapshot(step, year, exit_log)
            snapshots.append(snap)

        return snapshots

    def _snapshot(self, step, year, exit_log) -> Snapshot:
        per_tube = []
        for tier, tube in sorted(self.tubes_by_tier.items()):
            per_tube.append({
                "tier"          : tier,
                "headcount"     : tube.headcount,
                "eff_volume"    : round(tube.effective_volume, 2),
                "demand_height" : round(tube.demand_height, 2),
                "vacuum"        : round(tube.vacuum, 2),
                "fill_pct"      : round(tube.fill_pct, 4),
                "density"       : round(tube.density, 4),
            })
        return Snapshot(
            step        = step,
            year        = round(year, 2),
            total_balls = sum(t.headcount for t in self.tubes_by_tier.values()),
            pool_size   = self.pool.size,
            per_tube    = per_tube,
            exits       = exit_summary(exit_log),
        )

    # ── Output helpers ────────────────────────────────────────────────────────

    @staticmethod
    def to_dataframe(snapshots: List[Snapshot]) -> pd.DataFrame:
        """Flatten snapshots into a tidy DataFrame for analysis."""
        rows = []
        for snap in snapshots:
            for t in snap.per_tube:
                rows.append({
                    "step"        : snap.step,
                    "year"        : snap.year,
                    "total_balls" : snap.total_balls,
                    "pool_size"   : snap.pool_size,
                    "exits_quit"  : snap.exits.get("voluntary_quit", 0),
                    "exits_ret"   : snap.exits.get("retirement", 0),
                    "exits_shock" : snap.exits.get("shock", 0),
                    **t,
                })
        return pd.DataFrame(rows)
