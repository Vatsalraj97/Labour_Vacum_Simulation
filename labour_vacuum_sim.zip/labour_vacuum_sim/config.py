# =============================================================================
# config.py  —  All placeholders in one place
# =============================================================================
# Every value marked PLACEHOLDER can be replaced with real data.
# Source suggestions are noted in comments.
# =============================================================================

# ── Simulation time ───────────────────────────────────────────────────────────
START_YEAR   = 2025
END_YEAR     = 2033
QUARTERS_PER_YEAR = 4
TOTAL_STEPS  = (END_YEAR - START_YEAR) * QUARTERS_PER_YEAR  # 32 quarters

# ── Tube definitions ──────────────────────────────────────────────────────────
# 10 skill tiers from 0.1 (entry) to 1.0 (expert)
# Diameter is proportional to tier — wider tubes hold more workers
TUBE_TIERS = [round(t * 0.1, 1) for t in range(1, 11)]
# [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]

# PLACEHOLDER: diameter multiplier per tier
# Currently linear — could be shaped by real job distribution data (BLS OES)
TUBE_DIAMETER_SCALE = 2.0  # tube diameter = tier * TUBE_DIAMETER_SCALE

# ── Initial worker population ─────────────────────────────────────────────────
# PLACEHOLDER: Total US manufacturing workers Dec 2025
# Source: BLS CES series CEU3000000001
INITIAL_WORKFORCE = 12_690_000

# PLACEHOLDER: Distribution of workers across tiers at t=0
# Currently a rough bell curve centred on tier 0.4 (general manufacturing)
# Replace with BLS OES occupational distribution data
INITIAL_TIER_DISTRIBUTION = {
    0.1: 0.08,   # ~1.0M  entry / assembly
    0.2: 0.13,   # ~1.6M  semi-skilled operators
    0.3: 0.16,   # ~2.0M  skilled operators
    0.4: 0.18,   # ~2.3M  core manufacturing (agriculture maps ~0.7)
    0.5: 0.16,   # ~2.0M  senior operators / technicians
    0.6: 0.12,   # ~1.5M  lead technicians
    0.7: 0.09,   # ~1.1M  specialists (agriculture centroid)
    0.8: 0.05,   # ~0.6M  senior specialists
    0.9: 0.02,   # ~0.3M  master craftspeople
    1.0: 0.01,   # ~0.1M  experts / system designers
}

# ── Inflow (new entrants from population pipeline) ────────────────────────────
# PLACEHOLDER: Annual US birth cohort reaching working age (~18-22)
# Source: US Census Bureau, American Community Survey Table B01001
ANNUAL_WORKING_AGE_COHORT = 4_000_000

# PLACEHOLDER: % of working-age entrants going into manufacturing
# Source: BLS Current Population Survey, Table 14 (industry of employment)
# Has been declining from ~12% (2000) to ~8% (2024)
MFG_ENTRY_PCT = 0.085

# Annual manufacturing entrants (derived — do not edit directly)
ANNUAL_MFG_ENTRANTS = int(ANNUAL_WORKING_AGE_COHORT * MFG_ENTRY_PCT)
# ~340,000 / year → ~85,000 / quarter

# PLACEHOLDER: Skill distribution of NEW entrants (always enter low tiers)
# New entrants can only enter tubes 0.1–0.4
# Source: BLS JOLTS, apprenticeship programme completion data (DOL)
ENTRANT_SKILL_MEAN  = 0.12   # most start near bottom
ENTRANT_SKILL_STD   = 0.06   # some variation (community college grads vs raw)
ENTRANT_SKILL_MIN   = 0.01
ENTRANT_SKILL_MAX   = 0.35   # hard cap — no new entrant starts above 0.35

# ── Growth engine parameters ──────────────────────────────────────────────────
# Skill growth formula:
#   dskill/dt = BASE_GROWTH_RATE
#               * (skill / tube_tier) ^ ALPHA      # proximity to ceiling
#               * (1 / (1 + BETA * density))       # crowding penalty
#               * tube_tier                         # higher tiers grow faster

# PLACEHOLDER: Base quarterly growth rate
# Source: no direct empirical source — calibrate against apprenticeship
#         programme completion data (DOL RAPIDS database)
BASE_GROWTH_RATE = 0.015   # ~6% skill gain per year at base

# PLACEHOLDER: Alpha — controls convexity of proximity effect
# Higher alpha = faster growth only very close to ceiling; lower = more linear
# Reasonable range: 0.5–2.5
ALPHA = 1.4

# PLACEHOLDER: Beta — crowding sensitivity
# Higher beta = growth slows sharply in dense tubes
# Reasonable range: 0.1–1.0
BETA = 0.3

# ── Graduation ────────────────────────────────────────────────────────────────
# A ball graduates when skill > tube_tier
# It then enters MarketPool and seeks the next tube up

# PLACEHOLDER: Quarterly probability that a graduated ball actually FINDS
# a slot in the next tube (job market matching efficiency)
# 1.0 = instant placement; 0.5 = 50% chance each quarter
PLACEMENT_PROBABILITY = 0.7

# ── Exit engine parameters ────────────────────────────────────────────────────

# Voluntary quit (career change / burnout)
# PLACEHOLDER: Quarterly probability of voluntary exit, by tier
# Source: BLS JOLTS quit rates by industry (Table 16)
# Lower tiers have higher quit rates
QUIT_RATE_BY_TIER = {
    0.1: 0.045,  # ~18%/yr  — high churn at entry
    0.2: 0.038,
    0.3: 0.030,
    0.4: 0.025,  # ~10%/yr  — general manufacturing baseline
    0.5: 0.020,
    0.6: 0.015,
    0.7: 0.012,
    0.8: 0.009,
    0.9: 0.007,
    1.0: 0.005,  # ~2%/yr   — experts rarely leave
}

# Retirement (age-driven)
# PLACEHOLDER: Quarterly retirement probability by worker age quartile
# Source: BLS CPS, SIPP (Survey of Income & Program Participation)
# In simulation, age is proxied by total tenure in the system
RETIREMENT_TENURE_THRESHOLD = 40   # quarters (10 years) before retirement risk rises
RETIREMENT_BASE_RATE        = 0.008  # quarterly rate once above threshold
# Scales up with tenure beyond threshold — see exit_engine.py

# Policy shock (ICE raids, layoffs, recession)
# PLACEHOLDER: Probability of a shock event occurring in any given quarter
# Source: calibrate against historical enforcement data (DHS enforcement stats)
SHOCK_PROBABILITY    = 0.05   # 5% chance per quarter — placeholder
SHOCK_REMOVAL_RATE   = 0.02   # % of workers removed if shock occurs
# PLACEHOLDER: Shock hits lower tiers harder (higher immigrant share)
SHOCK_TIER_WEIGHTS = {
    0.1: 3.0,   # food processing, textiles — highest exposure
    0.2: 2.5,
    0.3: 1.5,
    0.4: 1.0,   # baseline
    0.5: 0.8,
    0.6: 0.5,
    0.7: 0.3,
    0.8: 0.2,
    0.9: 0.1,
    1.0: 0.05,
}

# ── Demand signals ────────────────────────────────────────────────────────────
# Demand raises the HEIGHT of each tube — does not create workers

# PLACEHOLDER: Annual industry output growth rate
# Source: UNIDO World Manufacturing Production Q1 2025
INDUSTRY_GROWTH_RATE = 0.019   # 1.9% per year

# PLACEHOLDER: Total reshoring labour demand 2025–2033 (millions)
# Source: Reshoring Initiative 2024 + CHIPS Act + IRA + IIJA
RESHORING_TOTAL_M = 0.300   # 300k workers total over 9 years

# PLACEHOLDER: Tier distribution of reshoring demand
# Reshoring tends to create mid-tier jobs (CNC, electronics assembly)
RESHORING_TIER_WEIGHTS = {
    0.1: 0.05,
    0.2: 0.10,
    0.3: 0.20,
    0.4: 0.25,
    0.5: 0.20,
    0.6: 0.12,
    0.7: 0.05,
    0.8: 0.02,
    0.9: 0.01,
    1.0: 0.00,
}

# ── Monte Carlo parameters ────────────────────────────────────────────────────
MC_RUNS   = 500
MC_SEED   = 42

# Parameter variation ranges for MC sampling (Normal distributions)
# PLACEHOLDER: Std devs represent uncertainty — tighten as more data arrives
MC_PARAMS = {
    "alpha":              {"mean": ALPHA,              "std": 0.30},
    "beta":               {"mean": BETA,               "std": 0.08},
    "base_growth_rate":   {"mean": BASE_GROWTH_RATE,   "std": 0.004},
    "mfg_entry_pct":      {"mean": MFG_ENTRY_PCT,      "std": 0.010},
    "shock_probability":  {"mean": SHOCK_PROBABILITY,  "std": 0.020},
    "industry_growth":    {"mean": INDUSTRY_GROWTH_RATE,"std": 0.005},
    "reshoring_total_m":  {"mean": RESHORING_TOTAL_M,  "std": 0.075},
}
